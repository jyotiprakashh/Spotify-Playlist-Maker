package main

import (
	// "context"
	"net/http"
	// "fmt"
	"log"
	// "os"

	// "github.com/aws/aws-lambda-go/events"
	// "github.com/aws/aws-lambda-go/lambda"
	"github.com/joho/godotenv"
	"github.com/jyotiprakashh/Spotify-Playlist-Maker/serverless_backend/functions"
)

func init() {
	if err := godotenv.Load(); err != nil {
		log.Fatalf("Error loading .env file")
	}
}

func main() {
	http.HandleFunc("/generate-playlist", functions.GeneratePlaylistHandler)
	http.HandleFunc("/add-playlist", functions.AddPlaylistHandler)
	http.HandleFunc("/user-profile", functions.UserProfileHandler)
	http.HandleFunc("/login", functions.LoginHandler)
	http.HandleFunc("/callback", functions.CompleteAuth)
	http.HandleFunc("/logout", functions.LogoutHandler)

	// port := os.Getenv("PORT")
	// if port == "" {
	// 	port = "8080"
	// }

	// log.Printf("Server is running on port %s", port)
	// log.Fatal(http.ListenAndServe(":"+port, nil))

	// lambda.Start(Handler)

}

// func Handler(req events.APIGatewayProxyRequest) (events.APIGatewayProxyResponse, error) {
// 	switch req.Path {
// 	  case "/login":
		
// 	}
// }
